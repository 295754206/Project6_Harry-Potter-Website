window.onscroll = function() {
    //获取当前的scrollTop
    var current_top = $(window).scrollTop();
    if (current_top > 100) {
        $(".top").show();
    } else {
        $(".top").hide();
    }
};
$("#toTop").click(function() {
    $(document).scrollTop(0);
});
var toTop = document.getElementById("toTop");
toTop.onclick = function() {
    document.scrollTop = document.body.scrollTop = 0;
};